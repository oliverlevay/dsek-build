import{r as n}from"./index.BanBdRDU.js";const t=n(new Date,e=>{e(new Date);const a=setInterval(()=>{e(new Date)},1e3);return()=>clearInterval(a)});export{t as n};
