const s="minio.api.sandbox.dsek.se",o="documents",I="files";export{I as P,s as a,o as b};
