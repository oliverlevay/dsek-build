import"./index.DQfRr7yB.js";const e=(t,i)=>!!(i!=null&&i.policies.includes(t));export{e as i};
