const s=""+new URL("../assets/eye.C7Kfwj5-.svg",import.meta.url).href,e=""+new URL("../assets/swirl.BFs5_jVE.svg",import.meta.url).href;export{s as e,e as s};
