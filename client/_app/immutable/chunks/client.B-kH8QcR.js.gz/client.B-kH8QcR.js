import{a as r}from"./public.D6ikzIky.js";const s=`https://${r}/`,o=t=>t&&(t.startsWith("minio/")?`${s}${t.substring(6)}`:t);export{o as g};
