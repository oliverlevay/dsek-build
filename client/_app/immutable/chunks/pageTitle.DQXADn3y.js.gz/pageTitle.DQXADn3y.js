import{w as e}from"./index.BanBdRDU.js";const o=e("D-sektionen");export{o as p};
