import{L as m}from"../chunks/21.eyQct81Z.js";export{m as component};
