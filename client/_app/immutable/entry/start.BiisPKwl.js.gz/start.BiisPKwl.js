import{j as a}from"../chunks/123.BVaw0gZK.js";export{a as start};
